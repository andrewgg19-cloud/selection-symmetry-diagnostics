# Cover Letter Template

Dear Editor,

Please consider the manuscript **"Selection Symmetry as an Operational Diagnostic for Correlations under Data Filtering: Reproducible Stress Tests across Bell, Biomedical, and Dataset-Shift Examples"** for publication.

This manuscript presents a reproducible and interdisciplinary framework for diagnosing when a reported correlation is invariant under data selection and when it can be explained as information introduced by the filtering mechanism itself. The work connects selection bias, mutual information, Bell-CHSH stress testing, missing-data/dropout examples, AI/ML dataset filtering, single-cell quality-control filtering, and reproducible simulation.

The contribution is methodological rather than a claim of new physics or an audit of existing experiments. It is also complementary to existing selection-correction methods rather than a replacement for them. All numerical examples are synthetic and reproducible. The repository includes scripts, CSV outputs, figures, and automated tests.

We believe the manuscript will be of interest to readers working on data filtering, selection bias, causal inference, reproducible computational science, AI/ML dataset documentation, and foundations-adjacent diagnostics of correlations.

Sincerely,

German Garcia
